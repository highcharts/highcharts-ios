//
//  HIChartsJSONSerializable.h
//  Highcharts
//
//  Created by krzysiek on 17.02.2017.
//  Copyright © 2017 Highsoft AS. All rights reserved.
//
#import <Foundation/Foundation.h>


@interface HIChartsJSONSerializable : NSObject
-(NSDictionary *)getParams;
@end
